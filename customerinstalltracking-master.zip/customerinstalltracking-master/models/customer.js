'use strict';
module.exports = (Sequelize, DataTypes) => {
  var customer = Sequelize.define('customer', {
    name: DataTypes.STRING,
    name_ref: DataTypes.STRING,
    email: DataTypes.STRING,
    middleware: DataTypes.STRING,
    checklist: DataTypes.STRING,
  }, {});
  customer.associate = function(models){
    customer.hasMany(models.location)
  };
  return customer;
};


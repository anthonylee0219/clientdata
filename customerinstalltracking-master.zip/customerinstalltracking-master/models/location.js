'use strict';
module.exports = (Sequelize, DataTypes) => {
  var location = Sequelize.define('location', {
    site: DataTypes.STRING,
    site_ref: DataTypes.STRING,
    config: DataTypes.STRING,
    backhaul: DataTypes.STRING,
    address: DataTypes.STRING,
    sensor: DataTypes.STRING,
    gwalert: DataTypes.STRING,
    wreport: DataTypes.STRING,
    name: DataTypes.STRING,
    insdate: DataTypes.STRING,
    installer: DataTypes.STRING,
    gwtype: DataTypes.STRING,
    macadress: DataTypes.STRING,
    webpass: DataTypes.STRING,
    conpass: DataTypes.STRING,
    openvpn: DataTypes.STRING,
    sshproxy: DataTypes.STRING,
    simvalue: DataTypes.STRING,
    custssid: DataTypes.STRING,
    custpass: DataTypes.STRING,
    staticip: DataTypes.STRING,
    provider: DataTypes.STRING,

  }, {});
  location.associate = function(models){
    location.belongsTo(models.customer, {foreignKey: 'customerId'});
  };
  location.associate = function(models){
    location.hasMany(models.contact);
  };
  return location;
};
'use strict';
module.exports = (Sequelize, DataTypes) => {
  var contact = Sequelize.define('contact', {
    name: DataTypes.STRING,
    email: DataTypes.STRING,
    phone: DataTypes.STRING,
    admin: DataTypes.STRING,
    site: DataTypes.STRING
  }, {});
  contact.associate = function(models){
    contact.belongsTo(models.location, {foreignKey: 'locationId'});
  };
  return contact;
};
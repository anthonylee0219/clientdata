'use strict';
module.exports = (Sequelize, DataTypes) => {
  var User = Sequelize.define('User',{
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      allowNull: false,
      primaryKey: true
     },
     username: {
       allowNull: true,
       type: DataTypes.STRING
     },
     firstname: {
       allowNull: true,
       type: DataTypes.STRING
     },
     lastname: {
     	allowNull: true,
     	type: DataTypes.STRING
     },
     password: {
      allowNull: true,
      type: DataTypes.STRING
     },
     email: {
      allowNull: false,
      type: DataTypes.STRING,
      unique: true
     },
   })
   return User;
}
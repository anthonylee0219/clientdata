install node_modules (npm install)

Postgres database setting:
Database: "orm-client-db"
Role: "orm-user"

Add hasAuth to routes to require login.

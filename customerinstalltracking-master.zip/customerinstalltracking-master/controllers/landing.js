const models = require('../models')
const Location = require('../models').location;

exports.get_landing = function(req, res, next) {
  res.render('landing', { user: req.user });
}

exports.show_files = function(req, res, next) {
  res.render('lead/clientfiles');
}

exports.submit_name = function(req, res, next) {
	return models.customer.create({
		name: req.body.input_name,
		name_ref: req.body.input_name,
		email: req.body.input_email,
		middleware: req.body.input_middleware,
		checklist: req.body.input_checklist
	}).then(name => {
		res.redirect('/');
	})
}
	
exports.show_names = function(req, res, next) {
	return models.customer.findAll().then(customers => {
		  res.render('lead/clients', { customers:customers });
	})
}

exports.show_edit_client = function(req, res, next) {
	return models.customer.findOne({
		where: {
			id:req.params.customer_id
		}
	}).then(customer => {
		  res.render('edit_client', { customer:customer });
	})
}

exports.edit_client = function(req, res, next) {

	return models.customer.update({
		name_ref: req.body.input_nameref,
		email: req.body.input_email,
		middleware: req.body.input_middleware,
		checklist: req.body.input_checklist,
	}, {
		where: {
			id:req.params.customer_id
		}
	}).then(result => {
		res.redirect('/');
	})
}

exports.show_onecust = function(req, res, next) {
	return models.location.findOne({
		where: {
			id: req.params.customer_id
		}
	}).then(customer => {
		res.render('lead/oneloc', {customer : customer});
	});	
}


exports.show_onecontact = function(req, res, next) {
	return models.contact.findOne({
		where: {
			id: req.params.location_id
		}
	}).then(contact => {
		res.render('contact/onecontact', {contact : contact});
	});	
}

exports.show_custinfo = function(req, res, next) {
	return models.location.findAll({
		where: {
			name: req.params.customer_name
		}
	}).then(customers => {
		res.render('lead/custinfo', {customers : customers});
	});	
}

exports.show_submit_etc = function(req, res, next) {
	return models.customer.findOne({
		where: {
			name: req.params.customer_name
		},
	}).then(customer => {
		res.render('addlocation', {customer:customer});
	})

}
exports.submit_etc = function(req, res, next) {
	return models.location.create({
		name: req.params.customer_name,
		site: req.body.input_site,
		site_ref: req.body.input_site,
		config: req.body.input_config,
		backhaul: req.body.input_backhaul,
		sensor: req.body.input_sensor,
		gwalert: req.body.input_gwalert,
		wreport: req.body.input_wreport,
		insdate: req.body.input_insdate,
		address: req.body.input_address,
		installer: req.body.input_installer,
		gwtype: req.body.input_gwtype,
		macadress: req.body.input_macadress,
		webpass: req.body.input_webpass,
		conpass: req.body.input_conpass,
		openvpn: req.body.input_openvpn,
		sshproxy: req.body.input_sshproxy,
		simvalue: req.body.input_simvalue,
		custssid: req.body.input_custssid,
		custpass: req.body.input_custpass,
		staticip: req.body.input_staticip,
		provider: req.body.input_provider,

	}).then(result => {
		res.redirect('/custinfos/'+req.params.customer_name+"?");
	})
}

exports.show_custinfolist = function(req, res, next) {
	return models.location.findAll({
		where: {
			name: req.params.customer_name
		}
	}).then(customers => {
		res.render('lead/custinfo', {customers : customers});
	});	
}

exports.show_edit_name = function(req, res, next) {
	return models.location.findOne({
		where: {
			id: req.params.customer_id
		}
	}).then(customer => {
		res.render('lead/edit_customer', {customer : customer});
	});
	
}

exports.edit_name = function(req, res, next) {

	return models.location.update({
		name: req.body.input_client,
		site_ref: req.body.input_siteref,
		config: req.body.input_config,
		backhaul: req.body.input_backhaul,
		sensor: req.body.input_sensor,
		gwalert: req.body.input_gwalert,
		wreport: req.body.input_wreport,
		insdate: req.body.input_insdate,
		address: req.body.input_address,
		installer: req.body.input_installer,
		gwtype: req.body.input_gwtype,
		macadress: req.body.input_macadress,
		webpass: req.body.input_webpass,
		conpass: req.body.input_conpass,
		openvpn: req.body.input_openvpn,
		sshproxy: req.body.input_sshproxy,
		simvalue: req.body.input_simvalue,
		custssid: req.body.input_custssid,
		custpass: req.body.input_custpass,
		staticip: req.body.input_staticip,
		provider: req.body.input_provider,
	}, {
		where: {
			id:req.params.customer_id
		}
	}).then(customers => {
		res.redirect('/custinfos/'+req.body.input_client);
	})
}

exports.delete_name_json = function(req, res, next) {
	return models.location.destroy({
		where: {
			id:req.params.customer_id
		}
	}).then(result => {
		res.send({ msg: "Success"});
	})
}

exports.delete_contact_json = function(req, res, next) {
	return models.contact.destroy({
		where: {
			id:req.params.location_id
		}
	}).then(result => {
		res.send({ msg: "Success"});
	})
}


exports.show_contactinfo = function(req, res, next) {
	return models.location.findOne({
		where: {
			site: req.params.customer_site
		}
	}).then(location => {
		res.render('contact/addcontact', {location : location});
	});	
}

exports.show_contact = function(req, res, next) {
	return models.location.findOne({
		where: {
			site: req.params.customer_site
		}
	}).then(location => {
		res.render('contact/addcontact', {location : location});
	});
	
}

exports.submit_contact = function(req, res, next) {
	return models.contact.create({
		site: req.params.location_site,
		name: req.body.contact_name,
		email: req.body.contact_email,
		phone: req.body.contact_phone,
		admin: req.body.contact_admin,

	}).then(result => {
		res.redirect('/custinfos/'+req.params.location_site + "/contact/list?");
	})
}

exports.show_contactlist = function(req, res, next) {
	return models.contact.findAll({
		where: {
			site: req.params.location_site
		}
	}).then(locations => {
		res.render('contact/contactinfo', {locations : locations});
	});	
}

exports.show_edit_contact = function(req, res, next) {
	return models.contact.findOne({
		where: {
			id: req.params.location_id
		}
	}).then(contact => {
		res.render('contact/edit_contact', {contact : contact});
	});
	
}

exports.edit_contact = function(req, res, next) {

	return models.contact.update({
		site: req.body.contact_site,
		name: req.body.contact_name,
		email: req.body.contact_email,
		phone: req.body.contact_phone,
		admin: req.body.contact_admin,
	}, {
		where: {
			id:req.params.location_id
		}
	}).then(result => {
		res.redirect('/custinfos/'+req.body.contact_site+'/contact/list');
	})
}
////////////////////////////////////////////////////



exports.delete_name = function(req, res, next) {
	return models.customer.destroy({
		where: {
			id:req.params.customer_id
		}
	}).then(result => {
		res.redirect('/');
	})
}

exports.delete_contact = function(req, res, next) {
	return models.contact.destroy({
		where: {
			id:req.params.location_id
		}
	}).then(result => {
		res.redirect('/');
	})
}

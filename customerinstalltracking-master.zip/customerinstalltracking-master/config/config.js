module.exports={
 "development": {
    "username": "orm_user",
    "password": '5102',
    "database": "orm-client-db",
    "host": "127.0.0.1",
    "dialect": "postgres",
    "port":5432
  },
  "test": {
    "username": "carsonm",
    "password": null,
    "database": "customer_install_tracking",
    "host": "opsensedevdb01",
    "dialect": "postgres",
    "port":5432
  },
  "production": {
    "username": "carsonm",
    "password": null,
    "database": "customer_install_tracking",
    "host": "opsensedevdb01",
    "dialect": "postgres",
    "port":5432
  }
}

var express = require('express');
var router = express.Router();
let landing = require('../controllers/landing');
let user = require('../controllers/user');
let {isLoggedIn, hasAuth} = require('../middleware/hasAuth.js')

router.get('/login', user.show_login);
router.get('/signup', user.show_signup);
router.post('/login', user.login);
router.post('/signup', user.signup);
router.post('/logout', user.logout);
router.get('/logout', user.logout);

/* GET home page. */
router.get('/', landing.show_names);
router.get('/files/:customer_id', landing.show_files);

router.get('/clients', landing.get_landing);
router.post('/clients/add', landing.submit_name);
router.get('/custinfos/:customer_name',landing.show_custinfo);
router.get('/custinfos/:customer_id/one',landing.show_onecust);
router.get('/custinfos/:customer_name/addloc', landing.show_submit_etc);
router.get('/custinfos/:customer_name/list',landing.show_custinfolist);
router.post('/custinfos/:customer_name/addloc/submit', landing.submit_etc);

//Edit Client
router.get('/clientinfo/:customer_id', landing.show_edit_client);
router.post('/clientinfo/:customer_id/submit', landing.edit_client);

router.get('/custinfos/:customer_id/edit', landing.show_edit_name);
router.post('/custinfos/:customer_id/edit/submit', landing.edit_name);
router.post('/custinfos/:customer_id/delete', landing.delete_name);

router.get('/custinfos/:customer_site/contact',landing.show_contactinfo);
router.get('/custinfos/:customer_site/contact/addcontact', landing.show_contact);
router.post('/custinfos/:location_site/contact/submit', landing.submit_contact);
router.get('/custinfos/:location_site/contact/list',landing.show_contactlist);
router.post('/custinfos/:location_id/contact/delete-json', landing.delete_contact_json);


router.get('/custinfos/:location_id/contact/edit', landing.show_edit_contact);
router.get('/custinfos/:location_id/contact/one', landing.show_onecontact);
router.post('/custinfos/:location_id/contact/edit/submit', landing.edit_contact);

// router.get('/lead/:lead_id', landing.show_name);
router.post('/custinfos/:customer_id/delete-json', landing.delete_name_json);
router.post('/:customer_id/delete', landing.delete_name);

module.exports = router;

let validator = require('validator');
let models = require('../models');
const validateCreateUserFields = function(errors, req) {
	if (!validator.isEmail(req.body.email)) {
		errors["email"] = "Enter valid email";

	}
	if(!validator.isAscii(req.body.password)) {
		errors["password"] = "invalid";
	}
	if (!validator.isLength(req.body.password, {min: 8, max: 25})) {
		errors["password"] = "incorrect length";
	}
} 

exports.validateUser = function(errors, req) {
	return new Promise(function(resolve, reject) {
		validateCreateUserFields(errors, req);
		return models.User.findOne({
			where: {
				email: req.body.email
			}
		}).then(u => {
			if(u!== null) {
				errors["email"] = "email in use. login or reset pw";
			}
			resolve(errors);
		})
	})
}